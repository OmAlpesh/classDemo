//
//  ViewController.swift
//  ClassDemo
//
//  Created by alpesh patel on 2/22/16.
//  Copyright © 2016 alpesh patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        var newgeoPoint = GeoPoint()
        newgeoPoint.latitude = 42.12
        newgeoPoint.longitude = -12

        NSLog("newgeoPoint.latitude %f", newgeoPoint.latitude)
         NSLog("newgeoPoint.longitude %f", newgeoPoint.longitude)
        
        let memberwiseGeoPoint = GeoPoint(latitude: 20.15, longitude: 29.29)
        NSLog("memberwiseGeoPoint %f %f", memberwiseGeoPoint.latitude,memberwiseGeoPoint.longitude)
        
        let origin = Point(x: 0, y: 0)
          NSLog("origin %d %d", origin.x, origin.y)
        
        
        let size = SizeStruct(width: 200, height: 300)
          NSLog("size %d %d", size.width,size.height)
        
        
        var rectObj = Rect(origin: origin, size: size)
          NSLog("rect %d %d %d %d", rectObj.origin.x, rectObj.origin.y, rectObj.size.width, rectObj.size.height)
        rectObj.size.width = 80
    
        let center = rectObj.center()
         NSLog("center %d %d", center.x,center.y)
        
        
        
        
        
        
        let PersonOne = Person(name: "Alpesh", age: 30)
        NSLog("PersonOne %@ %d", PersonOne.name1, PersonOne.age1)

        
        let PersonTwo = Person(name: "Jignesh", age: 25, nickname: "Jigs")
        NSLog("PersonTwo %@ %d %@", PersonTwo.name1, PersonTwo.age1, PersonTwo.nickname1!)
        
        
        let SecondClassObj1 = Mutant(name: "Jignesh1", age: 27,level: 7, superPower: "Flight", nickname: "Jigs1")
        NSLog("SecondClass1--- %@ %d %d %@ %@", SecondClassObj1.name1, SecondClassObj1.age1,SecondClassObj1.level1,SecondClassObj1.superPower1, SecondClassObj1.nickname1!)
        
        
        let SecondClassObj2 = Mutant(name: "Jignesh2", age: 21,level: 9, superPower: "Flight2", nickname: "Jigs2")
        NSLog("SecondClass2--- %@ %d %d %@ %@", SecondClassObj2.name1, SecondClassObj2.age1,SecondClassObj2.level1,SecondClassObj2.superPower1, SecondClassObj2.nickname1!)
        
        let check = SecondClassObj2.isMorePowerful(SecondClassObj1)
          NSLog("check---%@", check.description)
        
        
        let varOne:simpleClass = simpleClass()
        varOne.stringProperty = "Hello world"
        
        let varTwo = varOne
        NSLog("varTwo---%@", varTwo.stringProperty)
        
        
        let newSimpleClassObj = simpleClass()
        
        newSimpleClassObj.RectObj.origin.x = 10
        newSimpleClassObj.RectObj.origin.y = 20
        newSimpleClassObj.RectObj.size.width = 500
        newSimpleClassObj.RectObj.size.height = 1000
        NSLog("newSimpleClassObj---%f %f %f %f",newSimpleClassObj.RectObj.origin.x,newSimpleClassObj.RectObj.origin.y,newSimpleClassObj.RectObj.size.width,newSimpleClassObj.RectObj.size.height)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    
    struct GeoPoint {
    
        var latitude = 0.0
        var longitude = 0.0
    }
    
    struct Point {
        var x:Int, y:Int
    }
    
    struct SizeStruct{
        var width:Int, height:Int
    }
    
    struct Rect {
        var origin:Point, size:SizeStruct
        
        func center() -> Point{
            let x = origin.x + (size.width / 2)
            let y = origin.y + (size.height / 2)
            return Point(x: x, y: y)
        }
    }
    
    
    
    class Person
    {
        var name1:String
        var age1:Int
        var nickname1:String?
        
        init(name:String, age:Int, nickname:String? = nil)
        {
            self.name1 = name
            self.age1 = age
            self.nickname1 = nickname
        }
    
    }
    
    
    class Mutant: Person
    {
        var level1:Int
        var superPower1:String
        
        init(name: String, age: Int, level: Int, superPower: String, nickname : String? = nil)
        {
            self.level1=level
            self.superPower1=superPower
            
            super.init(name:name, age: age, nickname: nickname)
        }
        
        func isMorePowerful(_ mutant:Mutant) -> Bool
        {
            return (level1 > mutant.level1)
        }
    }
    
    
    class simpleClass {
        
        var stringProperty = "My string"
        var RectObj:CGRect = CGRect(x: 0.0, y: 0.0, width: 100, height: 300)
    }
    
}

